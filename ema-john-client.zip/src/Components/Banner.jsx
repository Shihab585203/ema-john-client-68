const Banner = () => {
    return (
        <div>
            
        </div>
    );
};

export default Banner;