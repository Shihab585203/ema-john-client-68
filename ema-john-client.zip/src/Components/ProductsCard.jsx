import React, { useEffect, useState } from "react";
import Products from "./Products";

const ProductsCard = () => {
  const [ products, setProducts ] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/products")
      .then((res) => res.json())
      .then((data) => setProducts(data));
  }, []);
  return (
    <div className="grid grid-cols-3 gap-16 w-11/12 mx-auto my-10">
      {products.map((product) => (
        <Products key={product._id} product={product} />
      ))}
    </div>
  );
};

export default ProductsCard;
