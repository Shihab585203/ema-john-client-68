export const clientsFeedback = [
    {
        id: 1,
        heading: 'Efficient Collaborating',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quis illum sequi pariatur ratione aliquam, sed nam maiores beatae! Nisi esse dolore velit perspiciatis tenetur laboriosam corrupti ratione ducimus.',
        img: 'https://randomshot.infostarr.com/wp-content/uploads/2021/12/10760-Babar-Azam.jpg',
        name: 'Babar Azam',
        title: 'CEO at ABC Corporation'
    },
    {
        id: 2,
        heading: 'Intuitive Design',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quis illum sequi pariatur ratione aliquam, sed nam maiores beatae! Nisi esse dolore velit perspiciatis tenetur laboriosam corrupti ratione ducimus.',
        img: 'https://imgv3.fotor.com/images/gallery/Realistic-Male-Profile-Picture.jpg',
        name: 'Ai kull',
        title: 'CEO at ABC Corporation'
    },
    {
        id: 3,
        heading: 'Mindblowing Service',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quis illum sequi pariatur ratione aliquam, sed nam maiores beatae! Nisi esse dolore velit perspiciatis tenetur laboriosam corrupti ratione ducimus.',
        img: 'https://d2qp0siotla746.cloudfront.net/img/use-cases/profile-picture/template_0.jpg',
        name: 'David Rice',
        title: 'CEO at ABC Corporation'
    },
    {
        id: 4,
        heading: 'Efficient Collaborating',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quis illum sequi pariatur ratione aliquam, sed nam maiores beatae! Nisi esse dolore velit perspiciatis tenetur laboriosam corrupti ratione ducimus.',
        img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRj6bWgNIwJN0dvsgnYIsGuExDL9FLUDIw0xuORZARex7NgC7SLacOgmEp8vp5ECNQzu2o&usqp=CAU',
        name: 'Ai Zulfiqar',
        title: 'CEO at ABC Corporation'
    },
    {
        id: 5,
        heading: 'Intuitive Design',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quis illum sequi pariatur ratione aliquam, sed nam maiores beatae! Nisi esse dolore velit perspiciatis tenetur laboriosam corrupti ratione ducimus.',
        img: 'https://image.lexica.art/full_jpg/acf5676d-e1bb-47cf-8e64-b171543de0ec',
        name: 'Siddique',
        title: 'CEO at ABC Corporation'
    },
    {
        id: 6,
        heading: 'Mindblowing Service',
        description: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quis illum sequi pariatur ratione aliquam, sed nam maiores beatae! Nisi esse dolore velit perspiciatis tenetur laboriosam corrupti ratione ducimus.',
        img: 'https://pbs.twimg.com/profile_images/1485050791488483328/UNJ05AV8_400x400.jpg',
        name: 'Rishi kapoor',
        title: 'CEO at ABC Corporation'
    },
]